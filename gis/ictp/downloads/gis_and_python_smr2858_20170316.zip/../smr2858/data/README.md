## Safecast data

API call used to fetch safecast data for the exercise:
https://api.safecast.org/measurements.json?distance=500000&latitude=37.4218&longitude=141.0337&captured_after=2011-03-10&captured_before=2012-04-10&per_page=20000
